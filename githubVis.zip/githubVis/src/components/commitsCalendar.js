import BEM from "../utils/BEM.js";
const b = BEM("GithubVis")

const getColor = (max) => (count) => {
    if (count === 0  ) return "#ebedf0"

    const range = (count * 100) / max

    if (range < 25) return  "#c6e48b"
    if (range < 50) return  "#7bc96f"
    if (range < 75) return  "#239a3b"

    return  "#239a3b"
}

const {map, pipe} = R;
const {addDays, startOfDay} = dateFns;

const getRangeFromDateAndDuration = (startDate) => (durationInDays) =>
    new Array(durationInDays).fill().map( (_, i) => addDays(startDate, i))

const RenderCalendarItem = (colorFn) => (item) =>
    `<div class="${b("item")}" style="background: ${colorFn(item)};" title="${item}"></div>`

const CommitsCalendar = (mapOfCommitsByDate) => {
    const startDate = startOfDay('2019-01-06T00:00:00.000Z')

    const calendar = pipe(
        getRangeFromDateAndDuration(startDate),
        map( date => mapOfCommitsByDate.get(Number(date)) || 0)
    ) (52 * 7)

    const maxCommitCount = Math.max(...calendar);
    const colorFn = getColor(maxCommitCount);

    return `
        <div class="${b()}">
            ${calendar.map(RenderCalendarItem (colorFn) ).join("")}
        </div>
    `
}

export default CommitsCalendar
