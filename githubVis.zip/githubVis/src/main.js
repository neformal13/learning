import CommitsCalendar from "./components/commitsCalendar.js";
import timestamps from "./timestamps.js";

const {pipe, groupWith, equals, map, reduce} = R
const {startOfDay} = dateFns;

const getCommitsFromTimestamps =  pipe(
    map((dateStr) => Number(startOfDay(dateStr))),
    groupWith(equals),
    reduce( (acc, group) => acc.set(group[0], group.length), new Map)
)

const render = (el) => {
    const commits  = getCommitsFromTimestamps(timestamps)
    el.innerHTML = CommitsCalendar(commits);
}

render(document.getElementById("root"))
